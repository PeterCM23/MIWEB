// Establecemos el nombre con el que almacenaremos el token en el localStorage.
export const TOKEN_LOCAL_STORAGE_KEY = 'authToken';
