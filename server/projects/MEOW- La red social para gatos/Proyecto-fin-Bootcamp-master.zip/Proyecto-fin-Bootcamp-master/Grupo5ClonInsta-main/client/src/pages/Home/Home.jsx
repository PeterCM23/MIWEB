function Home() {

    return (
        <h1>Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim doloremque odio, minima est libero dicta cupiditate rem suscipit voluptatum quaerat consequatur perspiciatis itaque amet doloribus molestiae voluptates quod. Fugiat, placeat.</h1>
    )
}

export default Home